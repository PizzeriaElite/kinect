﻿using UnityEngine;
using System.Collections;

public abstract class Button:MonoBehaviour
{
	public abstract void Click();
}
